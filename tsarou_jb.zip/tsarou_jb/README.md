## Hello JetBrains Team!

### Build the project:

`mkdir build && cd build` \
`cmake ..` \
`make`

### Run tests:

`./test_parser`

### Run parser:

`./parser test_json "store.store_id"`\

(running tests creates a sample json)

### Known issues:

1. `size()` is not implemented;
2. Expressions in `max()/min()` are expected to evaluate to integers