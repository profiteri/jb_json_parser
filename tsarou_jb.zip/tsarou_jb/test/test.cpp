#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include <iostream>
#include "baby_json.h"

std::string execute_command(const std::string& command) {
    std::array<char, 128> buffer;
    std::string last_line;
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(command.c_str(), "r"), pclose);
    if (!pipe) {
        throw std::runtime_error("popen() failed!");
    }
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        last_line = buffer.data();
    }
    if (!last_line.empty() && last_line.back() == '\n') {
        last_line.pop_back();
    }
    return last_line;
}

void prepare_file(const std::string& text) {
    std::string filename = "test_json";
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "could not open the file " << filename << " for writing." << std::endl;
    }
    file << text;
    file.close();
}

TEST_CASE("default_jb") {
    prepare_file("{\"a\": { \"b\": [ 1, 2, { \"c\": \"test\" }, [11, 12] ]}}");

    //Trivial expressions with JSON paths
    auto res = execute_command("./parser test_json \"a.b[1]\"");
    CHECK(res == "2");

    res = execute_command("./parser test_json \"a.b[2].c\"");
    CHECK(res == "\"test\"");

    res = execute_command("./parser test_json \"a.b\"");
    CHECK(res == "[1,2,{\"c\":\"test\"},[11,12]]");

    //Expressions in the subscript operator
    res = execute_command("./parser test_json \"a.b[a.b[1]].c\"");
    CHECK(res == "\"test\"");

    //Intrinsic functions: min, max
    res = execute_command("./parser test_json \"max(a.b[0], a.b[1])\"");
    CHECK(res == "2");

    res = execute_command("./parser test_json \"min(a.b[3])\"");
    CHECK(res == "11");

    //Number literals
    res = execute_command("./parser test_json \"max(a.b[0], 10, a.b[1], 15)\"");
    CHECK(res == "15");
}

TEST_CASE("min/max") {
    prepare_file("{\"ar\": [1,2,3], \"a\": { \"b\": [ 1, 2, { \"c\": \"test\" }, [10, {\"c\":0}, 15, 13] ]}}");
    auto res = execute_command("./parser test_json \"a.b[min(a.b[0], max(a.b[1], a.b[3][0], a.b[3][1].c))]\"");
    CHECK(res == "2");

    execute_command("./parser test_json \"min(min(ar), max(a.b[1], a.b[3][0]))\"");
    CHECK(res == "2");

    res = execute_command("./parser test_json \"min(a.b[0], a.b[3][1].c, max(a.b[1], a.b[3][0]))\"");
    CHECK(res == "0");

    res = execute_command("./parser test_json \"max(1, 2, 3)\"");
    CHECK(res == "3");

    res = execute_command("./parser test_json \"min(ar)\"");
    CHECK(res == "1");

    res = execute_command("./parser test_json \"a.b[min(ar)]\"");
    CHECK(res == "2");
}

TEST_CASE("simple array") {
    prepare_file("{\"a\": []");
    auto res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[]");

    prepare_file("{\"a\": [\"a\"]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[\"a\"]");

    prepare_file("{\"a\": [-1]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[-1]");

    prepare_file("{\"a\": [1]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[1]");

    prepare_file("{\"a\": [true]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[true]");

    prepare_file("{\"a\": [false]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[false]");

    prepare_file("{\"a\": [null]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[null]");

    prepare_file("{\"a\": [{\"o1\":\"o1\"}]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[{\"o1\":\"o1\"}]");

    res = execute_command("./parser test_json \"a[0]\"");
    CHECK(res == "{\"o1\":\"o1\"}");

    res = execute_command("./parser test_json \"a[0].o1\"");
    CHECK(res == "\"o1\"");

    prepare_file("{\"a\": [{\"o1\":\"o1\"}, true, false, null, -1, 1, 0.25, \"a\"]");
    res = execute_command("./parser test_json \"a\"");
    CHECK(res == "[{\"o1\":\"o1\"},true,false,null,-1,1,0.25,\"a\"]");
}

TEST_CASE("simple object") {
    prepare_file(json);

    std::string expr = "store.store_id";
    std::string result = "\"12345\"";
    auto res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "store.location.city";
    result = "\"Marketville\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "store.categories[0].name";
    result = "\"Electronics\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "store.categories[1].products[0].price";
    result = "1499.99";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "store.categories[0].products[1].specifications.processor";
    result = "\"Intel i7\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "customers[0].orders[0].items[0].total_price";
    result = "699.99";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "customers[1].address.city";
    result = "\"Mallville\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "store.categories[0].products[0].reviews[1].comment";
    result = "\"Good, but battery life could be better.\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "suppliers[0].contact.phone";
    result = "\"555-0101\"";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);

    expr = "customers[1].orders[0].shipping.cost";
    result = "19.99";
    res = execute_command("./parser test_json \"" + expr + "\"");
    CHECK(res == result);
}