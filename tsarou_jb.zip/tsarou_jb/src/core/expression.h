#pragma once

#include <string>
#include <vector>
#include <iostream>

#include "json.h"

class expression {

    enum {MAX, MIN, NUMERIC, CHAIN} type;

    std::vector<std::string_view> call_chain;
    static std::shared_ptr<const json> root;

    void set_type(std::string_view);

    std::vector<std::string_view> extract_call_chain(std::string_view);
    json evaluate_call_chain(const json&) const;

    json evaluate_intrinsic_function() const;
    static std::vector<int> to_int_vector(const json &obj);
    static int to_int(const json &obj);

public:
    explicit expression(std::string_view);
    json evaluate_on(const json&) const;
    static void set_root(std::shared_ptr<const json>);
};