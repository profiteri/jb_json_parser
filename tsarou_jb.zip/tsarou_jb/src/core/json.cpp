#include "json.h"
#include "../utils/parser.h"

json::json(std::string_view content) {

    if (content.begin() == content.end()) throw std::runtime_error("no json passed");

    else if (content.front() == '[') {
        set_array(content);
    }
    else if (content.front() == '{') {
        set_object(content);
    }
    else {
        set_primitive(content);
    }
}

json::json(int content) {
    type = INT;
    data = content;
}

json::json(double content) {
    type = DOUBLE;
    data = content;
}

void json::set_object(std::string_view content) {
    this->type = OBJECT;
    data = json_map{};
    auto data_ptr = std::get_if<json_map>(&data);

    auto pairs = parser::extract_kv_pairs(content);

    for (const auto& p : pairs) {
        data_ptr->insert({p.first, json{p.second}});
    }
}

const json::json_map& json::get_object() const {
    if (type == OBJECT) return std::get<json_map>(data);
    else throw std::runtime_error("wrong type, expected OBJECT");
}

bool json::is_object() const {
    return type == OBJECT;
}

void json::set_array(std::string_view content) {
    this->type = ARRAY;
    data = json_array{};
    auto data_ptr = std::get_if<json_array>(&data);

    auto ar = parser::parse_array(content, '[', ']');
    data_ptr->reserve(ar.size());
    for (const auto& el : ar) {
        data_ptr->push_back(json{el});
    }
}

const std::vector<json>& json::get_array() const {
    if (type == ARRAY) return std::get<std::vector<json>>(data);
    else throw std::runtime_error("wrong type, expected OBJECT");
}

bool json::is_array() const {
    return type == ARRAY;
}

void json::set_primitive(std::string_view content) {
    this->type = PRIMITIVE;
    auto it{content.begin()};
    data = parser::extract_primitive_value(it, content.cend());
}

std::string_view json::get_primitive() const {
    if (type == PRIMITIVE) {
        return std::get<std::string_view>(data);
    }
    else throw std::runtime_error("wrong type, expected PRIMITIVE");
}

std::string json::get_numeric() const {
    if (type == INT) {
        return std::to_string(std::get<int>(data));
    }
    else if (type == DOUBLE) {
        return std::to_string(std::get<double>(data));
    }
    else throw std::runtime_error("wrong type, expected INT or DOUBLE");
}

int json::get_int() const {
    if (type == INT) {
        return std::get<int>(data);
    }
    else throw std::runtime_error("wrong type, expected INT");
}

bool json::is_primitive() const {
    return type == PRIMITIVE;
}

bool json::is_numeric() const {
    return (type == INT) || (type == DOUBLE);
}

std::string json::to_string() const {
    std::string res{};
    if (type == OBJECT) {
        auto map = get_object();
        res += ("{");
        for (auto it = map.begin(); it != map.end(); ++it) {
            res += '"';
            res += it->first;
            res += '"';
            res += ":";
            res += it->second.to_string();
            if (std::next(it) != map.end()) { res += ","; }
        }
        res += ("}");
    }
    else if (type == ARRAY) {
        auto array = get_array();
        res += ("[");
        for (auto it = array.begin(); it != array.end(); ++it) {
            res += it->to_string();
            if (std::next(it) != array.end()) { res += ","; }
        }
        res += ("]");
    }
    else if (type == PRIMITIVE) {
        res += get_primitive();
        //res += parser::trim_chars(primitive, '"', '"');;
    }
    else if (type == INT || type == DOUBLE) {
        res += get_numeric();
    }
    return res;
}