#pragma once

#include <unordered_map>
#include <string>
#include <variant>
#include <utility>

class json {

    using json_map = std::unordered_map<std::string_view, json>;
    using json_array = std::vector<json>;

    enum {OBJECT, ARRAY, PRIMITIVE, INT, DOUBLE} type;

    std::variant<
        json_map,
        json_array,
        std::string_view, //for number, string, bool, null
        int,
        double
    > data;

    void set_object(std::string_view);
    void set_array(std::string_view);
    void set_primitive(std::string_view);

public:
    explicit json(std::string_view);
    explicit json(int);
    explicit json(double);

    bool is_object() const;
    const json_map& get_object() const;

    bool is_array() const;
    const json_array& get_array() const;

    bool is_primitive() const;
    std::string_view get_primitive() const;

    bool is_numeric() const;
    std::string get_numeric() const;
    int get_int() const;

    std::string to_string() const;
};
