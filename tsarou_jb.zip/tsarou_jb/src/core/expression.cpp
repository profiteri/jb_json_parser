#include <stack>
#include <utility>

#include "expression.h"
#include "../utils/parser.h"

std::shared_ptr<const json> expression::root = nullptr;

void expression::set_root(std::shared_ptr<const json> obj) {
    expression::root = obj;
}

void expression::set_type(std::string_view sw) {
    if (sw.starts_with(parser::MAX_STR())) {
        type = MAX;
    }
    else if (sw.starts_with(parser::MIN_STR())) {
        type = MIN;
    }
    else if (!std::holds_alternative<std::monostate>(parser::extract_number(sw))) {
        type = NUMERIC;
    }
    else {
        type = CHAIN;
    }
}

expression::expression(std::string_view content) {

    set_type(content);

    switch (type) {
        case MIN: call_chain.push_back(content); break;
        case MAX: call_chain.push_back(content); break;
        case CHAIN: call_chain = extract_call_chain(content); break;
        case NUMERIC: call_chain.push_back(content);
    }
}

json expression::evaluate_on(const json& obj) const {
    switch (type) {
        case MIN: return evaluate_intrinsic_function();
        case MAX: return evaluate_intrinsic_function();
        case CHAIN: return evaluate_call_chain(obj);
        case NUMERIC: return json{call_chain.front()};
    }
}

/**
 * For the following expression: "a.b[3][a.b[3]].c[max(1,2)].d", call chain is:
 * a, b, [3], [a.b[3]], c, [max(1,2)], d
 */
std::vector<std::string_view> expression::extract_call_chain(std::string_view content) {
    std::vector<std::string_view> res;
    auto brackets = std::stack<char>{};
    int ind{0};

    for (char c : content) {

        if (c == '.' && brackets.empty() && ind != 0) {
            res.emplace_back(content.substr(0, ind));
            content.remove_prefix(ind + 1);
            ind = 0;
        }

        else if (parser::is_opening_bracket(c)) {
            if (brackets.empty() && ind != 0) {
                //chained subscript operator:
                //[0][1]
                //   ↑
                res.emplace_back(content.substr(0, ind));
                content.remove_prefix(ind);
                ind = 0;
            }
            brackets.push(c);
            ++ind;
        }

        else if (parser::is_closing_bracket(c)) {
            if (brackets.top() == parser::reverse_bracket(c)) {
                brackets.pop();
                ++ind;
            }
            else throw std::runtime_error("expected closing bracket, but got: " + std::string{c});
        }

        else {
            ++ind;
        }
    }

    if (ind != 0) {
        res.emplace_back(content.substr(0, ind));
    }

    return res;
}

json expression::evaluate_call_chain(const json& obj) const {
    const json* curr = &obj;
    for (std::string_view sub_expr : call_chain) {
        //array subscript expression
        if (sub_expr.starts_with('[')) {
            sub_expr = parser::trim_chars(sub_expr, '[', ']');

            auto maybe_num = parser::extract_number(sub_expr);

            //not a number, needs further evaluation
            if (!std::holds_alternative<int>(maybe_num)) {
                expression index_expr{sub_expr};
                json index_json = index_expr.evaluate_on(*expression::root);
                std::string index_str = index_json.is_primitive()
                        ? std::string(index_json.get_primitive())
                        : index_json.get_numeric();
                maybe_num = parser::extract_number(index_str);
            }
            auto ind = std::get<int>(maybe_num);
            curr = &(curr->get_array().at(ind));
        }

        //json path
        else {
            curr = &(curr->get_object().at(sub_expr));
        }
    }
    return *curr;
}

json expression::evaluate_intrinsic_function() const {
    std::string_view sw = call_chain.front();
    sw.remove_prefix(3);
    std::vector<std::string_view> sw_elements = parser::parse_array(sw, '(', ')');
    std::vector<int> int_elements; int_elements.reserve(sw_elements.size());

    for (auto el : sw_elements) {
        json obj = expression{el}.evaluate_on(*root);

        if (obj.is_array() && sw_elements.size() == 1) {
            int_elements = to_int_vector(obj);
        }
        else {
            int_elements.push_back(to_int(obj));
        }
    }

    auto res = (type == MAX)
            ? std::max_element(int_elements.begin(), int_elements.end())
            : std::min_element(int_elements.begin(), int_elements.end());
    return json{*res};
}

std::vector<int> expression::to_int_vector(const json& obj) {
    std::vector<int> res;
    for (const json& el : obj.get_array()) {
        res.push_back(to_int(el));
    }
    return res;
}

int expression::to_int(const json& obj) {
    if (obj.is_numeric()) {
        return obj.get_int();
    }
    else if (obj.is_primitive()) {
        auto num = parser::extract_number(obj.get_primitive());
        if (std::holds_alternative<int>(num)) {
            return std::get<int>(num);
        }
        else throw std::runtime_error("primitive not convertable to int");
    }
    else {
        throw std::runtime_error("obj not convertable to int");
    }
}
