#include <string>
#include <cstdio>

namespace file_utils {
    std::string get_file_content(const char* file_name) {
        FILE* f = fopen(file_name, "r");
        if (!f) {
            throw std::runtime_error("File could not be opened");
        }

        fseek(f, 0, SEEK_END);
        size_t size = ftell(f);
        if (size == 0) {
            fclose(f);
            return "";  // Return an empty string for an empty file
        }

        std::string content;
        content.resize(size);

        rewind(f);
        size_t read_size = fread(&content[0], sizeof(char), size, f);
        fclose(f);

        if (read_size != size) {
            throw std::runtime_error("Failed to read the complete file");
        }

        return content;
    }
}