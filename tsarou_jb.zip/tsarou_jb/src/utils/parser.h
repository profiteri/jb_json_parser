#pragma once

#include <algorithm>
#include <cctype>
#include <locale>
#include <stack>
#include <exception>
#include <iterator>
#include <iostream>

class parser {

public:

    static constexpr std::string_view TRUE_STR() { return "true"; };
    static constexpr std::string_view FALSE_STR() { return "false"; };
    static constexpr std::string_view NULL_STR() { return "null"; };
    static constexpr std::string_view MAX_STR() { return "max("; };
    static constexpr std::string_view MIN_STR() { return "min("; };

    static bool is_opening_bracket(char c) {
        return c == '[' || c == '{' || c == '(';
    }

    static bool is_closing_bracket(char c) {
        return c == ']' || c == '}' || c == ')';
    }

    static bool is_bracket(char c) {
        return is_opening_bracket(c) || is_closing_bracket(c);
    }

    template<std::random_access_iterator ra_iter>
    static bool is_intrinsic_function(ra_iter it, ra_iter end) {
        if (end - it < 4) return false;

        auto sw = std::string_view(it, it + 4);
        return (sw == MAX_STR() || sw == MIN_STR());
    }

    static char reverse_bracket(char c) {
        if (c == '{') return '}';
        else if (c == '}') return '{';
        else if (c == '[') return ']';
        else if (c == ']') return '[';
        else if (c == '(') return ')';
        else if (c == ')') return '(';
        else return ' ';
    }

    static std::string remove_extra_spaces(const std::string& str) {
        std::string res; res.reserve(str.size());
        bool open_string = false;
        for (auto c : str) {
            if (c == '"') open_string = !open_string;
            if (open_string || !std::isspace(c)) res.push_back(c);
        }
        return res;
    }

    template<std::random_access_iterator ra_iter>
    static void skip_spaces_and_char(ra_iter& it, ra_iter end, char c) {
        bool skipped_char = false;
        while (it != end && (std::isspace(*it) || (*it == c && !skipped_char))) {
            if (*it == c) skipped_char = !skipped_char;
            ++it;
        }
    }

    template<std::random_access_iterator ra_iter>
    static std::string_view extract_numeric_string(ra_iter& it, ra_iter end) {
        ra_iter start = it;
        for ( ; it != end && !std::isspace(*it) && *it != ','; ++it);
        return { start, it };
    }

    template<std::random_access_iterator ra_iter>
    static std::string_view extract_string(ra_iter& it, ra_iter end) {
        ra_iter start = it;
        for (++it; it != end && *it != '"'; ++it);
        if (it != end && *it == '"') ++it;
        return { start, it };
    }

    static std::pair<std::string_view, std::string_view> extract_array_components(std::string_view sw) {
        size_t start_ind = sw.find('[');
        size_t end_ind = sw.rfind(']');
        if (start_ind == std::string_view::npos || end_ind == std::string_view::npos) {
            return {sw, {}};
        }
        else {
            return {sw.substr(0, start_ind), sw.substr(start_ind + 1, end_ind - start_ind - 1)};
        }
    }

    static std::string_view trim_chars(std::string_view sw, char left, char right) {
        auto start = sw.begin(); auto end = sw.rbegin();
        skip_spaces_and_char(start, sw.end(), left);
        skip_spaces_and_char(end, sw.rend(), right);
        return {start, end.base()};
    }

    //string in double quotes, or a number, or true or false or null
    template<std::random_access_iterator ra_iter>
    static std::string_view extract_primitive_value(ra_iter& it, ra_iter end) {
        std::string_view res;

        //string
        if (*it == '"') {
            res = extract_string(it, end);
        }

        //true
        else if (end - it >= TRUE_STR().size() && std::equal(TRUE_STR().begin(), TRUE_STR().end(), it)) {
            it += TRUE_STR().size();
            return TRUE_STR();
        }

        //false
        else if (end - it >= FALSE_STR().size() && std::equal(FALSE_STR().begin(), FALSE_STR().end(), it)) {
            it += FALSE_STR().size();
            return FALSE_STR();
        }

        //null
        else if (end - it >= NULL_STR().size() && std::equal(NULL_STR().begin(), NULL_STR().end(), it)) {
            it += NULL_STR().size();
            return NULL_STR();
        }

        //number (first char either digit or minus)
        else if (std::isdigit(*it) || *it == '-') {
            res = extract_numeric_string(it, end);
        }

        else throw std::runtime_error("unexpected simple value");

        return res;
    }

    template<std::random_access_iterator ra_iter>
    static std::string_view extract_object_or_array(ra_iter& it, ra_iter end) {
        ra_iter start = it;
        std::stack<char> brackets;
        brackets.push(*it); ++it;

        for (bool open_string = false; it != end && !brackets.empty(); ++it) {
            if (*it == '"') {
                open_string = !open_string;
            }

            if (!is_bracket(*it)) {
                continue;
            }

            if (!open_string && is_opening_bracket(*it)) {
                brackets.push(*it);
            }

            if (!open_string && is_closing_bracket(*it)) {
                if (brackets.top() == reverse_bracket(*it)) brackets.pop();
                else throw std::runtime_error("expected closing bracket, but got: " + std::string{*it});
            }
        }
        return {start, it};
    }

    // extract keys and values
    static std::vector<std::pair<std::string_view, std::string_view>> extract_kv_pairs(std::string_view jsonString) {
        auto extractKey = [](std::string_view::iterator& it, std::string_view::iterator end) -> std::string_view {
            if (*it != '"') {
                throw std::runtime_error(
                        "expected semicolon in the beginning of the key, but got: " + std::string{*it});
            }
            return trim_chars(extract_string(it, end), '"', '"');
        };

        auto extractValue = [](std::string_view::iterator& it, std::string_view::iterator end) -> std::string_view {
            return is_bracket(*it) ? extract_object_or_array(it, end) : extract_primitive_value(it, end);
        };

        std::vector<std::pair<std::string_view, std::string_view>> result;

        jsonString = trim_chars(jsonString, '{', '}');

        // go through the JSON string and extract key-value pairs
        for (auto it = jsonString.begin(); it != jsonString.end(); ) {
            skip_spaces_and_char(it, jsonString.end(), ',');

            auto key = extractKey(it, jsonString.end());

            skip_spaces_and_char(it, jsonString.end(), ':');

            auto value = extractValue(it, jsonString.end());

            result.emplace_back(key, value);
        }

        return result;
    }

    //add parsing or recursive min/max
    static std::vector<std::string_view> parse_array(std::string_view sw, char opening_bracket, char closing_bracket) {

        sw = trim_chars(sw, opening_bracket, closing_bracket);
        auto it = sw.begin(), end = sw.end();

        std::vector<std::string_view> res{};
        auto start = sw.begin();

        for (bool open_string = false; it != end; ) {
            if (*it == '"') {
                open_string = !open_string;
                ++it;
            }

            else if (*it == ',' && !open_string) {
                res.emplace_back(start, it);
                ++it;
                start = it;
            }

            else if ((*it == '[' || *it == '{') && !open_string) {
                extract_object_or_array(it, end);
            }

            else if (is_intrinsic_function(it, end) && !open_string) {
                it += 3;
                extract_object_or_array(it, end);
            }

            else {
                ++it;
            }
        }
        if (start != it) res.emplace_back(start, it);

        return res;
    }

    static std::variant<int, double, std::monostate> extract_number(std::string_view sw) {
        auto str = std::string(sw);
        // try to parse as int
        try {
            size_t pos;
            int int_val = std::stoi(str, &pos);
            if (pos == str.length()) {
                return int_val;
            }
        }
        catch (const std::invalid_argument& e) {}
        catch (const std::out_of_range& e) {}

        // try to parse as double
        try {
            size_t pos;
            double double_val = std::stod(str, &pos);
            if (pos == str.length()) {
                return double_val;
            }
        }
        catch (const std::invalid_argument& e) {}
        catch (const std::out_of_range& e) {}

        return std::monostate{};
    }
};
