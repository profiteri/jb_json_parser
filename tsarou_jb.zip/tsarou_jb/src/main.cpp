#include <iostream>
#include "utils/io.h"
#include "core/json.h"
#include "core/expression.h"
#include "utils/parser.h"

int main(int argc, char* argv[]) {

    //formatting input
    const std::string content = parser::remove_extra_spaces(file_utils::get_file_content(argv[1]));
    const std::string expr_string = parser::remove_extra_spaces(argv[2]);

    std::shared_ptr<const json> obj_ptr;
    try {
        //parsing json
        obj_ptr = std::make_shared<const json>(content);
    } catch (std::exception& e) {
        std::cout << "Error: Couldn't parse JSON. Probably not valid" << std::endl;
    }

    //set global json object
    expression::set_root(obj_ptr);

    try {
        //parsing expression
        expression expr{expr_string};
        //evaluating expression
        auto res = expr.evaluate_on(*obj_ptr);
        std::cout << res.to_string() << std::endl;
    } catch (std::exception& e) {
        std::cout << "Error: Couldn't evaluate expression. Probably not valid" << std::endl;
    }

    return 0;
}